This project uses the Google Closure Compiler for compilation. Please make sure you installed it with FlashDevelop.
You can download it by using the AppMan from Tools->Install Software. Then just run: Test Project (F5).

More information: www.createjs.com, developers.google.com/closure/compiler
