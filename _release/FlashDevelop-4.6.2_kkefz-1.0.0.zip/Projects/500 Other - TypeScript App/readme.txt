To get TypeScript running with this project:

1. Install Node.js from http://nodejs.org
2. Install TypeScript by running "npm install -g typescript" in command prompt
3. Run Test Project (F5)

More information: www.typescriptlang.org
