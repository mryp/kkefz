AIR for desktop instructions

1. Configuration

	- edit 'bat\SetupSDK.bat' for the path to Flex SDK


2. Creating a self-signed certificate:

	- run 'bat\CreateCertificate.bat' to generate your self-signed certificate,

	(!) wait a minute before packaging.


3. Run/debug from FlashDevelop as usual (build F8, build&run F5 or Ctrl+Enter)


4. Packaging for release:

	- run 'PackageApp.bat' to only create the AIR setup
